var searchData=
[
  ['m_149',['m',['../classAreaEspera.html#ab29f2a32e97dfbbebfa576c46c768500',1,'AreaEspera::m()'],['../classCluster.html#aabe94e5dcab8699611f3d1014fba8c71',1,'Cluster::m()']]],
  ['memoria_5flibre_150',['memoria_libre',['../classProcesador.html#a734a0018d5dd5715e33e24babdcfb38e',1,'Procesador']]],
  ['memoria_5ftotal_151',['memoria_total',['../classProcesador.html#af9b292cca407f6ffe2605bbf54551dd8',1,'Procesador']]]
];

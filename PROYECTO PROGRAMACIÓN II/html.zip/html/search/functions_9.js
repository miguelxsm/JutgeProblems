var searchData=
[
  ['tiene_5fprocesos_5fpendientes_144',['tiene_procesos_pendientes',['../classPrioridad.html#a0a41088f13f6522083c8e6553d99a28c',1,'Prioridad']]]
];

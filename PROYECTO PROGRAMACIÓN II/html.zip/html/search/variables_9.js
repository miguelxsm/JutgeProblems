var searchData=
[
  ['tiempo_5frestante_159',['tiempo_restante',['../classProceso.html#aef3f2ad47d51eebd8519107108b49cf8',1,'Proceso']]]
];

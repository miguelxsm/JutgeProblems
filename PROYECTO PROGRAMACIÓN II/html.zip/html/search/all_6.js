var searchData=
[
  ['lee_5farea_5fespera_48',['lee_area_espera',['../classAreaEspera.html#a798d14b57af5e5102329abf8606e894a',1,'AreaEspera']]],
  ['lee_5fcluster_49',['lee_cluster',['../classCluster.html#a2721559ada8090a8958c7076ac13b4e2',1,'Cluster']]],
  ['leer_5fproceso_50',['leer_proceso',['../classProceso.html#acfc1b59d4fa0dd7bba4d02c6c6880ea9',1,'Proceso']]]
];

var searchData=
[
  ['peso_56',['peso',['../classProceso.html#a1afe4b15fc3a6f389bdb62b17143a4b3',1,'Proceso']]],
  ['pos_5fmemoria_57',['pos_memoria',['../classProcesador.html#aeaebb8482621c7408e635fb008599842',1,'Procesador']]],
  ['posiciones_58',['posiciones',['../classProcesador.html#aa43e37ce857ff7136cbda8cb77d0395a',1,'Procesador']]],
  ['prioridad_59',['Prioridad',['../classPrioridad.html',1,'Prioridad'],['../classPrioridad.html#a239123296380077ef6959111bf599a90',1,'Prioridad::Prioridad()']]],
  ['prioridad_2ecc_60',['Prioridad.cc',['../Prioridad_8cc.html',1,'']]],
  ['prioridad_2ehh_61',['Prioridad.hh',['../Prioridad_8hh.html',1,'']]],
  ['procesador_62',['Procesador',['../classProcesador.html',1,'Procesador'],['../classProcesador.html#a2651dac7b16c58f1dbc476845b4496bc',1,'Procesador::Procesador(int memoria, int p)'],['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()']]],
  ['procesador_2ecc_63',['Procesador.cc',['../Procesador_8cc.html',1,'']]],
  ['procesador_2ehh_64',['Procesador.hh',['../Procesador_8hh.html',1,'']]],
  ['procesador_5fcon_5fauxiliares_65',['procesador_con_auxiliares',['../classCluster.html#a09a126a1d8af3ac6f2a5b5942ac467f0',1,'Cluster']]],
  ['proceso_66',['Proceso',['../classProceso.html',1,'Proceso'],['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()']]],
  ['proceso_2ecc_67',['Proceso.cc',['../Proceso_8cc.html',1,'']]],
  ['proceso_2ehh_68',['Proceso.hh',['../Proceso_8hh.html',1,'']]],
  ['procesos_69',['procesos',['../classProcesador.html#a09415bd25560d91d36cbb2238f557d45',1,'Procesador']]],
  ['profundidad_70',['profundidad',['../classProcesador.html#a4fc2eddea662c9b91e84fc18abb28c9d',1,'Procesador']]],
  ['program_2ecc_71',['program.cc',['../program_8cc.html',1,'']]],
  ['práctica_20pro2_3a_20simulacióin_20del_20rendimiento_20de_20procesadores_20interconectados_72',['Práctica PRO2: Simulacióin del rendimiento de procesadores interconectados',['../index.html',1,'']]]
];

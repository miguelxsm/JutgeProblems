var searchData=
[
  ['tiempo_5frestante_76',['tiempo_restante',['../classProceso.html#aef3f2ad47d51eebd8519107108b49cf8',1,'Proceso']]],
  ['tiene_5fprocesos_5fpendientes_77',['tiene_procesos_pendientes',['../classPrioridad.html#a0a41088f13f6522083c8e6553d99a28c',1,'Prioridad']]]
];

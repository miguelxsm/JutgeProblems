var searchData=
[
  ['areaespera_78',['AreaEspera',['../classAreaEspera.html',1,'']]]
];

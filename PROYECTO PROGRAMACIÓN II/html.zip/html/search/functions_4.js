var searchData=
[
  ['hay_5fprocesos_5fpendientes_127',['hay_procesos_pendientes',['../classProcesador.html#aa44c25c70abd6f392cad5526b2ca7212',1,'Procesador']]],
  ['hueco_5fabajo_128',['hueco_abajo',['../classProcesador.html#a3c485d024f5baed9a371474d7e8f6b10',1,'Procesador']]],
  ['hueco_5farriba_129',['hueco_arriba',['../classProcesador.html#aa631419de971d3ac45472ed27d7fe45f',1,'Procesador']]]
];

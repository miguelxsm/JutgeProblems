var searchData=
[
  ['baja_5fproceso_5fprocesador_9',['baja_proceso_procesador',['../classCluster.html#a9f061cf2d13f9a5a7a8e2e1195e75238',1,'Cluster']]],
  ['busqueda_5fy_5fcambio_10',['busqueda_y_cambio',['../classCluster.html#a5015643ad50e5f225154ceb3781997b1',1,'Cluster']]]
];

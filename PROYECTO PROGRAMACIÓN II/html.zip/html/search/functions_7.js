var searchData=
[
  ['main_137',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fprocesador_5fcluster_138',['modificar_procesador_cluster',['../classCluster.html#a2a10ded67ff37b3ca0e471a8a4f153e2',1,'Cluster']]]
];

var searchData=
[
  ['eliminar_25',['eliminar',['../classProcesador.html#affb593c183c02e07836a347fb49ebc34',1,'Procesador']]],
  ['eliminar_5fprioridad_26',['eliminar_prioridad',['../classAreaEspera.html#aed199198cc1ff5011afe7a0a4a494341',1,'AreaEspera']]],
  ['eliminar_5fproceso_27',['eliminar_proceso',['../classProcesador.html#a0956d47080b39941b42edc4d22bfd01e',1,'Procesador']]],
  ['enviar_5fproceso_28',['enviar_proceso',['../classCluster.html#a7eddc41ed069a2779d3b5bf8ecf73c59',1,'Cluster']]],
  ['enviar_5fprocesos_5fcluster_29',['enviar_procesos_cluster',['../classAreaEspera.html#a69ea9209e3b3f4c5181ae913a94d50d6',1,'AreaEspera']]],
  ['enviar_5fprocesos_5fpriodidad_30',['enviar_procesos_priodidad',['../classPrioridad.html#a5f08e7b1208d224a1690897aa0ac6b93',1,'Prioridad']]],
  ['errores_31',['errores',['../program_8cc.html#afbcf4dcb25cf1bac7a381c7788ef7b2d',1,'program.cc']]],
  ['escribe_5farea_5fespera_32',['escribe_area_espera',['../classAreaEspera.html#a0d8a4875e412befe5dd2dce01f725d49',1,'AreaEspera']]],
  ['escribe_5fcluster_33',['escribe_cluster',['../classCluster.html#a82dfac01a185462096de95e7918ac07e',1,'Cluster']]],
  ['escribe_5fcluster_5farbol_34',['escribe_cluster_arbol',['../classCluster.html#a2f22e3aee2d90ff128587b830a12cd4f',1,'Cluster']]],
  ['escribe_5fprocesador_35',['escribe_procesador',['../classProcesador.html#a8c99403b80773091fcac1ce97d72c8d1',1,'Procesador']]],
  ['escribe_5fproceso_36',['escribe_proceso',['../classProceso.html#af599136a0968f5e64de95c3e58c7d23d',1,'Proceso']]],
  ['escribir_5fprioridad_37',['escribir_prioridad',['../classPrioridad.html#ac11c1709a1bde371738948e59bcd7715',1,'Prioridad']]],
  ['existe_5fproceso_38',['existe_proceso',['../classProcesador.html#ace943a1ef54559dcb81318ac7fada4b6',1,'Procesador']]]
];

var searchData=
[
  ['huecos_147',['huecos',['../classProcesador.html#a99c4a83e91559226010c475afd6bd2ee',1,'Procesador']]]
];

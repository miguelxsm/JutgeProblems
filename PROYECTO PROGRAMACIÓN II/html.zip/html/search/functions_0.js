var searchData=
[
  ['alta_5fproceso_5fprocesador_94',['alta_proceso_procesador',['../classCluster.html#a8ddab40fc160268e1ce4b9fdff14be0f',1,'Cluster']]],
  ['anadir_5fprioridad_95',['anadir_prioridad',['../classAreaEspera.html#a10f4cf6d756970f89f7b5a489369d042',1,'AreaEspera']]],
  ['anadir_5fproceso_96',['anadir_proceso',['../classPrioridad.html#af50e279f1730d6e2d8e35e5a1f505f2b',1,'Prioridad::anadir_proceso()'],['../classProcesador.html#a50b759c30ef81c8d6b3643b3a6f46302',1,'Procesador::anadir_proceso()']]],
  ['anadir_5fproceso_5fen_5fprioridad_97',['anadir_proceso_en_prioridad',['../classAreaEspera.html#a630d5814e9b86146485e414d7ac4a4b6',1,'AreaEspera']]],
  ['areaespera_98',['AreaEspera',['../classAreaEspera.html#a7963aabeb210931495ccb51d8ec61449',1,'AreaEspera']]],
  ['avanzar_5ftiempo_99',['avanzar_tiempo',['../classCluster.html#a3b93301a46cfa8cadf8d0121e234c386',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a91055a2cc9c3129051a762a9eb2a1f19',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#aacfa317b627623ffde171bd0e1419ac8',1,'Proceso::avanzar_tiempo()']]]
];

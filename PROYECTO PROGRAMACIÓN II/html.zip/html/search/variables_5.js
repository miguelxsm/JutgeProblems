var searchData=
[
  ['peso_152',['peso',['../classProceso.html#a1afe4b15fc3a6f389bdb62b17143a4b3',1,'Proceso']]],
  ['posiciones_153',['posiciones',['../classProcesador.html#aa43e37ce857ff7136cbda8cb77d0395a',1,'Procesador']]],
  ['procesos_154',['procesos',['../classProcesador.html#a09415bd25560d91d36cbb2238f557d45',1,'Procesador']]],
  ['profundidad_155',['profundidad',['../classProcesador.html#a4fc2eddea662c9b91e84fc18abb28c9d',1,'Procesador']]]
];

var searchData=
[
  ['q_73',['q',['../classPrioridad.html#a8d6daf9a05e24f81543b4a47b66cf3d0',1,'Prioridad']]]
];

var searchData=
[
  ['prioridad_80',['Prioridad',['../classPrioridad.html',1,'']]],
  ['procesador_81',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_82',['Proceso',['../classProceso.html',1,'']]]
];

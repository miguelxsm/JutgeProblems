var searchData=
[
  ['pos_5fmemoria_139',['pos_memoria',['../classProcesador.html#aeaebb8482621c7408e635fb008599842',1,'Procesador']]],
  ['prioridad_140',['Prioridad',['../classPrioridad.html#a239123296380077ef6959111bf599a90',1,'Prioridad']]],
  ['procesador_141',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a2651dac7b16c58f1dbc476845b4496bc',1,'Procesador::Procesador(int memoria, int p)']]],
  ['procesador_5fcon_5fauxiliares_142',['procesador_con_auxiliares',['../classCluster.html#a09a126a1d8af3ac6f2a5b5942ac467f0',1,'Cluster']]],
  ['proceso_143',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];
